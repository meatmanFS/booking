$ = jQuery.noConflict();
$(document).ready(function() {
//    var jVal = {
//        "check" : function(thisvar) {
//                var ele1 = $(thisvar);
//                var patt1 = /^(.){1,}$/i;
//                var patTime = /^([0-2]){1}([0-3]){1}:([0-5]){1}([0-9]){1}$/i;
//                var patTimeFull = /^([0-2]){1}([0-3]){1}:([0-5]){1}([0-9]){1}:([0-5]){1}([0-9]){1}$/i;
//                var datePatt = /^(19|20)\d\d-((0[1-9]|1[012])-(0[1-9]|[12]\d)|(0[13-9]|1[012])-30|(0[1-9]|1[0-2])-31)$/i;
//                var dateNotUniqPatt = /^((0[1-9]|1[012])-(0[1-9]|[12]\d)|(0[13-9]|1[012])-30|(0[1-9]|1[0-2])-31)$/i;
//                var descPatt = /^((WD){1}|(F){1}|(WE){1}|(H){1})$/i;
//                var costFloat = /^([0-9]*\.[0-9]{1,2}|[0-9]*)$/i;
//                
//                if(ele1.attr('type') === 'time')
//                {
//                    if(!patTime.test(ele1.val()) && !patTimeFull.test(ele1.val()))
//                    {
//                        ele1.parents('.form-group').addClass('has-error');
//                    }
//                    else
//                    {
//                        ele1.parents('.form-group').removeClass('has-error');
//                    }
//                }
//                else
//                {
//                    if(ele1.attr('id') === 'mi_booking_date_input')
//                    {
//                        if($('#date-every-year').is(':checked'))
//                        {
//                            if(!dateNotUniqPatt.test(ele1.val()))
//                            {
//                                ele1.parents('.form-group').addClass('has-error');
//                            }
//                            else
//                            {
//                                ele1.parents('.form-group').removeClass('has-error');
//                            }
//                        }
//                        else
//                        {
//                            if(!datePatt.test(ele1.val()))
//                            {
//                                ele1.parents('.form-group').addClass('has-error');
//                            }
//                            else
//                            {
//                                ele1.parents('.form-group').removeClass('has-error');
//                            }
//                        }                        
//                    }
//                    else
//                    {
//                        if(ele1.hasClass('what_day_input'))
//                        {
//                            if(!descPatt.test(ele1.val()))
//                            {
//                                ele1.parents('.form-group').addClass('has-error');
//                            }
//                            else
//                            {
//                                ele1.parents('.form-group').removeClass('has-error');
//                            }
//                        }
//                        else
//                        {
//                            if(!patt1.test(ele1.val()))  
//                            {
//                                ele1.parents('.form-group').addClass('has-error');
//                            }
//                            else
//                            {
//                                if(ele1.hasClass('cost_input'))
//                                {
//                                    if(!costFloat.test(ele1.val()) || !parseInt(ele1.val())>0)
//                                    {
//                                        ele1.parents('.form-group').addClass('has-error');
//                                    }
//                                    else
//                                    {
//                                        ele1.parents('.form-group').removeClass('has-error');
//                                    }
//                                }
//                                else
//                                {
//                                    ele1.parents('.form-group').removeClass('has-error');
//                                }
//                            }
//                        }
//                        
//                    }                    
//                }
//        }
//    };
//    $("html").on('keyup',".what_day_input, .time_input, .cost_input, .time-holiday input" , function(){
//        jVal.check(this);
//    });
//    $('.time_input, .time-holiday input').click(function(){
//        var thisis = this;
//        setTimeout(function(){ jVal.check(thisis); }, 500);        
//    });
//    $('.what_day_input, .time_input, .cost_input, .time-holiday input').mouseout(function(){
//        jVal.check(this);   
//    });
    $('.cost_input').keydown(function(e){        
        var char = String.fromCharCode(e.keyCode || e.charCode);
        var keyAllowed = true;
        switch(e.keyCode)
        {
            case 8: keyAllowed = false; break;
            case 46: keyAllowed = false; break;
            case 110: keyAllowed = false; break;    
        }
        if (e.keyCode >= 96 && e.keyCode <= 105)
        {
            keyAllowed = false;
        }
        if (e.keyCode >= 37 && e.keyCode <= 40)
        {
            keyAllowed = false;
        }
        var patt = /[0-9.]/;
        if(!patt.test(char))
        {
            if(keyAllowed)
            {
                e.preventDefault();
            }            
        }
    });
    $('.add-time-tamplates span').click(function(){
        $('.add-time-tamplates-inputs').toggle('slow');
    });
    $('.add-date-tamplate span').click(function(){
        $('.add-date-tamplate-inputs').toggle('slow');
    });
    $('.time-holiday input').jdPicker();
    $(':checkbox').iphoneStyle();
//    $('.container').click(function(){
//        if($(this).find('input').is(':checked'))
//        {
//            $('#mi_booking_date_input').attr('type','text');
//            $('#mi_booking_date_input').attr('title', $('#mi_booking_date_input').data('format-ununiq'));
//        }
//        else
//        {
//            $('#mi_booking_date_input').attr('type','date');
//            $('#mi_booking_date_input').attr('title', $('#mi_booking_date_input').data('format-uniq'));
//        }
//    });
});


