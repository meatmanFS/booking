$ = jQuery.noConflict();
$(document).ready(function() {
    var jVal = {
        "check" : function(thisvar) {
                var ele1 = $(thisvar);
                var patt1 = /^(.){1,}$/i;
                var patTime = /^([0-2]){1}([0-3]){1}:([0-5]){1}([0-9]){1}$/i;
                var patTimeFull = /^([0-2]){1}([0-3]){1}:([0-5]){1}([0-9]){1}:([0-5]){1}([0-9]){1}$/i;
                var datePatt = /(19|20)\d\d-((0[1-9]|1[012])-(0[1-9]|[12]\d)|(0[13-9]|1[012])-30|(0[1-9]|1[0-2])-31)/i;
                
                if(ele1.attr('type') === 'time')
                {
                    if(!patTime.test(ele1.val()) && !patTimeFull.test(ele1.val()))
                    {
                        ele1.parents('.form-group').addClass('has-error');
                    }
                    else
                    {
                        ele1.parents('.form-group').removeClass('has-error');
                    }
                }
                else
                {
                    if(ele1.attr('type') === 'date')
                    {
                        if(!datePatt.test(ele1.val()))
                        {
                            ele1.parents('.form-group').addClass('has-error');
                        }
                        else
                        {
                            ele1.parents('.form-group').removeClass('has-error');
                        }
                    }
                    else
                    {
                        if(!patt1.test(ele1.val()))  
                        {
                            ele1.parents('.form-group').addClass('has-error');
                        }
                        else
                        {
                            ele1.parents('.form-group').removeClass('has-error');
                        }
                    }                    
                }
        }
    };
    $("html").on('keyup',".what_day_input, .time_input, .cost_input, .time-holiday input" , function(){
        jVal.check(this);
    });
    $('.time_input, .time-holiday input').click(function(){
        var thisis = this;
        setTimeout(function(){ jVal.check(thisis); }, 500);        
    });
    $('.what_day_input, .time_input, .cost_input, .time-holiday input').mouseout(function(){
        jVal.check(this);   
    });
});


