<?php

defined( 'ABSPATH' ) or die( '<h3>No access to the file!</h3>' );

if (!class_exists('MI_Booking_Settings'))
{
    class MI_Booking_Settings extends MI_Booking {
        public $rooms;
        public $room;
        public $room_name;
        public $disp_days;
        public $show_city;
        public function __construct() {
            parent::__construct();
            global $wpdb;
            $this->rooms = $wpdb->get_results('SELECT * FROM '.$this->table_of_rooms.';' );
            $room_selected = get_option('mi_booking');
            $this->room = $room_selected['room_selected'];
            $this->plugin_settings();            
        }
        public function plugin_settings(){ 
            /*------------Room settings------------*/
            register_setting( 'mi_booking_room', 'mi_booking_room', array($this, 'save_settings') );
            add_settings_section( 'mi_booking_room_id', '', '', 'mi_booking_room' ); 
            add_settings_field('mi_booking_room_change_name', __('Change room name', 'mi_booking'), array($this, 'display_room_change_name' ), 'mi_booking_room', 'mi_booking_room_id' );
            add_settings_field('mi_booking_room_change_disp_days', __('Change displayed days', 'mi_booking'), array($this, 'change_disp_days' ), 'mi_booking_room', 'mi_booking_room_id' );
            add_settings_field('mi_booking_room_change_show_city', __('Show city', 'mi_booking'), array($this, 'show_city' ), 'mi_booking_room', 'mi_booking_room_id' );
        }
        public function save_settings($input) {
            global $wpdb;
            if(isset($input['change_name']))
            {
                $wpdb->update(
                    $this->table_of_rooms,
                    array('name_of_room' => $input['change_name']),
                    array('id' => $this->room),
                    array('%s'),
                    array('%d')    
                );
            }
            if(isset($input['disp_days']))
            {
                $wpdb->update(
                    $this->table_of_rooms,
                    array('number_of_days' => $input['disp_days']),
                    array('id' => $this->room),
                    array('%d'),
                    array('%d')    
                );
            }      
            $show_city = (isset($input['show_city']))? $input['show_city'] : false;
            if($show_city)
            {
                $wpdb->update(
                    $this->table_of_rooms,
                    array('show_town' => 1),
                    array('id' => $this->room),
                    array('%d'),
                    array('%d')    
                );
            }
            else
            {
                $wpdb->update(
                    $this->table_of_rooms,
                    array('show_town' => 0),
                    array('id' => $this->room),
                    array('%d'),
                    array('%d')    
                );
            }
            return $input;
        }
        public function room_selected_name() {
            foreach ($this->rooms as $room)
            {
                if ($room->id == $this->room)
                {
                    $this->room_name = $room->name_of_room;
                    $this->disp_days = $room->number_of_days;
                    $this->show_city = $room->show_town;
                }
            }
        }

        public function display_room_change_name() {
            $this->room_selected_name();
            ?>
                <div>
                    <input class="form-control" type="text" name="mi_booking_room[change_name]" value="<?php echo $this->room_name ?>" maxlength="150" />
                </div>
            <?php
        }
        public function change_disp_days() {
            $this->room_selected_name();
            ?>
                <div>
                    <input class="form-control" type="text" name="mi_booking_room[disp_days]" value="<?php echo $this->disp_days ?>" maxlength="10" />
                </div>
            <?php
        }
        public function show_city() {
            $this->room_selected_name();
            $show_city = (isset($this->show_city)) ? $this->show_city : false;
            ?>
                <div class="iphone-checkbox">
                    <input id="show_city" class="form-control" type="checkbox" name="mi_booking_room[show_city]" value="1" <?php if($show_city) checked(1, $show_city) ?>/>
                </div>
            <?php
        }
    }
}
























